"""Auto-generated file, do not edit by hand. 255 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_255 = [NumberFormat(pattern='(\\d{2})(\\d{3})(\\d{4})', format='\\1 \\2 \\3', leading_digits_pattern=['[67]']), NumberFormat(pattern='(\\d{2})(\\d{4})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['[67]'])]
